# jQuery in Action, third edition

This repository contains the  accompanying source code of the book "[jQuery in Action, third edition](http://www.manning.com/derosa/)".