require(['Car'], function(Car) {
   var car = new Car();
   alert(car.getOwner());
});