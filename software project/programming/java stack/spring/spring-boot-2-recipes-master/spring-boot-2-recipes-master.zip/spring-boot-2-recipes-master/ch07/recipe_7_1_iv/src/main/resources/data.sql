INSERT INTO customer (name, email) VALUES
                                          ('Marten Deinum', 'marten.deinum@conspect.nl'),
                                          ('Josh Long', 'jlong@pivotal.com'),
                                          ('John Doe', 'john.doe@island.io'),
                                          ('Jane Doe', 'jane.doe@island.io');
