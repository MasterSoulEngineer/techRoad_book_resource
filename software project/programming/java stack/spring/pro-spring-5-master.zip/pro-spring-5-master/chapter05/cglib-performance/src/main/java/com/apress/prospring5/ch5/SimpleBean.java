package com.apress.prospring5.ch5;

public interface SimpleBean {
    void advised();
    void unadvised();
}
