package com.apress.prospring5.ch3.sandbox;

/**
 * Created by iuliana.cosmina on 2/23/17.
 */
public interface Foo {

}
