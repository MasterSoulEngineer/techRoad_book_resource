package com.apress.prospring5.ch3.sandbox;

/**
 * Created by iuliana.cosmina on 2/23/17.
 */
import org.springframework.stereotype.Component;

@Component("kitchen")
public class Bar {

}
