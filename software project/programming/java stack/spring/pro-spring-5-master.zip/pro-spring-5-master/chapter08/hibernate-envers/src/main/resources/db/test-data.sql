insert into singer_audit (first_name, last_name, birth_date) values ('John', 'Mayer', '1977-10-16');
insert into singer_audit (first_name, last_name, birth_date) values ('Eric', 'Clapton', '1945-03-30');
insert into singer_audit (first_name, last_name, birth_date) values ('John', 'Butler', '1975-04-01');