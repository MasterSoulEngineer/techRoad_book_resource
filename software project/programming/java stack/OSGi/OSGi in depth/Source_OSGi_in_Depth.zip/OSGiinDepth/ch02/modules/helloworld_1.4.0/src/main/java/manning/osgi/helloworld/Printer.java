package manning.osgi.helloworld;

public interface Printer {
    
    public void print(String message);

}
