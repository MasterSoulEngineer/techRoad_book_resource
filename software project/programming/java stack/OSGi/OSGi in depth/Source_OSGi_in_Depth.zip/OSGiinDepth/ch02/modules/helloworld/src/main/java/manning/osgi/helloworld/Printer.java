package manning.osgi.helloworld;

public class Printer {
    
    public void print(String message) {
        System.out.println(message);
    }

}
