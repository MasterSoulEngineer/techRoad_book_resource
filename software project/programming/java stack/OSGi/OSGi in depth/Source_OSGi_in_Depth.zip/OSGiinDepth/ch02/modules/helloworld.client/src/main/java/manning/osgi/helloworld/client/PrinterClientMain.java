package manning.osgi.helloworld.client;

public class PrinterClientMain {
    
    public static void main(String args[]) {
        new PrinterClient().printMyMessage();
    }
}
