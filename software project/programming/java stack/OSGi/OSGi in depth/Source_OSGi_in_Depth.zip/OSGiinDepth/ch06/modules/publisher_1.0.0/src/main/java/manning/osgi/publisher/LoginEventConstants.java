package manning.osgi.publisher;

public interface LoginEventConstants {
    
    final static String TOPIC_NAME = "manning/osgi/login";
    
    final static String USERID = "userid";
    
    final static String TIMESTAMP = "timestamp";

}
