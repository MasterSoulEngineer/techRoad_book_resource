package manning.osgi.remoteinterfacedesign;

public interface CustomerRegistry {
    
    public Customer findCustomer(String name);

}
