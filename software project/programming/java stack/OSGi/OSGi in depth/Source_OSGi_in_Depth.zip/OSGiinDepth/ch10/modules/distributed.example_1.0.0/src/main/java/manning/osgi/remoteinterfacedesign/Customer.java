package manning.osgi.remoteinterfacedesign;

public interface Customer {
    
    public String getName();

    public String getAddress();
    
    public void setAddress(String address);
}
