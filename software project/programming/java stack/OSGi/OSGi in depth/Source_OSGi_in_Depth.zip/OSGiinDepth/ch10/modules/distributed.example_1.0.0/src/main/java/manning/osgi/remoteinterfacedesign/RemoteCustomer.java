package manning.osgi.remoteinterfacedesign;

public interface RemoteCustomer {
    
    public String getName();

    public String getAddress();
}
