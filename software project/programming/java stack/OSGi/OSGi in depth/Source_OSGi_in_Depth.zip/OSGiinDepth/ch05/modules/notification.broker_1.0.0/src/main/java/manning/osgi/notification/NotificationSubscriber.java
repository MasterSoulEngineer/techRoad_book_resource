package manning.osgi.notification;

public interface NotificationSubscriber {
    
    void onEvent(Object event);

}


