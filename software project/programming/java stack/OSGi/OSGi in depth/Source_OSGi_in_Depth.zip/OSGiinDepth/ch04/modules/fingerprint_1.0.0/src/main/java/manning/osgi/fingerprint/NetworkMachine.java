package manning.osgi.fingerprint;

public interface NetworkMachine {

}
