package manning.osgi.fingerprint;

import java.net.InetAddress;

public class TelnetImpl implements TelnetService {

    public void close() {
    }

    public void open(InetAddress target, int port) {
    }

    public String send(String text) {
        return null;
    }

}
