package manning.osgi.fingerprint;

public interface FingerprintService {
    
    byte [] hash(String input);

}
