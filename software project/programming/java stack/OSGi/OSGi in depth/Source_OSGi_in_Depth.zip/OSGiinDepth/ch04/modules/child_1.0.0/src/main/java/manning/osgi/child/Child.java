package manning.osgi.child;

import manning.osgi.parent.Parent;

public class Child extends Parent {
    
    public Child() {
        System.out.println("Child");
    }
}
