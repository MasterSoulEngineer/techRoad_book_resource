package manning.osgi.fingerprint;

public interface NetworkMachineService {

}
