package manning.osgi.parent;

public class Parent {
    
    public Parent() {
        System.out.println("Parent (private package)");
    }

}
