package manning.osgi.parent;

public class Parent {
    
    public Parent() {
        System.out.println("Parent (v2)");
    }
    
    public void newMethod() {
        System.out.println("new method");
    }
}
