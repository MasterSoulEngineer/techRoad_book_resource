package manning.osgi.subscriber;

import org.osgi.service.event.Event;
import org.osgi.service.event.EventHandler;

public class SimpleSubscriber implements EventHandler {

    public void handleEvent(Event event) {
        // Application code
    }

}
