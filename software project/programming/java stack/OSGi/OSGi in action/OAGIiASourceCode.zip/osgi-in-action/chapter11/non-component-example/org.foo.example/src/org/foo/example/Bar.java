package org.foo.example;

public interface Bar {

}
