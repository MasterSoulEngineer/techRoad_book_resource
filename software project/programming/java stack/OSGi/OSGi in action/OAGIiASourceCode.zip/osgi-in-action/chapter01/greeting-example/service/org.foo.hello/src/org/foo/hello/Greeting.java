package org.foo.hello;

public interface Greeting {
  void sayHello();
}
