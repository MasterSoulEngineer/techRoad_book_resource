package org.foo.shell;

import java.util.List;

public interface History {
  public List<String> get();
}
