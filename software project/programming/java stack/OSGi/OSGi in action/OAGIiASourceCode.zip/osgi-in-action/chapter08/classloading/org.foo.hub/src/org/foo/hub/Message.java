package org.foo.hub;

/**
 * An addressable message.
 */
public interface Message {
  String getAddress();
}
