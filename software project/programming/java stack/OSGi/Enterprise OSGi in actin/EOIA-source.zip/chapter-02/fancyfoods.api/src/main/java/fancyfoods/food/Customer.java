package fancyfoods.food;

public interface Customer {

	String getName();

	double getCreditLimit();

	double getBalance();

}
