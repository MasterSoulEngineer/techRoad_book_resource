package fancyfoods.food;

public interface Shop {

	double purchase(String foodName, String customerName, int quantity);

}
