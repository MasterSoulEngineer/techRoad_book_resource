package fancyfoods.department.foreign;

public interface LowTechOffer {

	public int getNumber();

}
