/*
 * Copyright (c) 2005 Chris Richardson
 * 
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 * 
 *      http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
 
package net.chrisrichardson.foodToGo.placeOrderTransactionScripts;

import java.util.*;

import net.chrisrichardson.foodToGo.placeOrderTransactionScripts.details.*;

/**
 * DTO returned by the script that updates the delivery info
 * 
 * @author cer
 * 
 */

public class UpdateDeliveryInfoResult extends PlaceOrderResult {

	public static final int CONFIRM_CHANGE = 0;

	public static final int NO_RESTAURANT_AVAILABLE = 1;

	public static final int SELECT_RESTAURANT = 2;

	public static final int BAD_STATE = 3;

	public static final int KEEP_RESTAURANT = 4;

	public static final int INVALID_DELIVERY_INFO = 5;

	private List availableRestaurants;

	public UpdateDeliveryInfoResult(int statusCode,
			PendingOrderDTO pendingOrder, List availableRestaurants) {
		super(statusCode, pendingOrder);
		this.availableRestaurants = availableRestaurants;
	}

	public List getAvailableResturants() {
		return availableRestaurants;
	}

}