These files are from the JBoss embeddable EJB 3
