package com.extensiblejava.route;

import com.extensiblejava.bill.*;

public abstract class Router {

	public abstract String route(Routable routable);
}