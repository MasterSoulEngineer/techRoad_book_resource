package com.extensiblejava.route;

public interface Routable {
	public String route();
}