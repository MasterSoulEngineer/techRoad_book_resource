package com.extensiblejava.main;

public interface InjectedInterface {
	public void injection();
	public void setUid(String uid);
	public void setPwd(String pwd);
}