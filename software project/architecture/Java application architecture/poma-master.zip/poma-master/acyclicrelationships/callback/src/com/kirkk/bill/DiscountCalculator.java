package com.kirkk.bill;

import java.math.BigDecimal;

public interface DiscountCalculator {
	public BigDecimal getDiscountAmount();
}