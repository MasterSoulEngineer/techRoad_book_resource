package com.extensiblejava.employee;

import java.math.BigDecimal;

public interface PayrollRunner {
	public BigDecimal runPayroll(BigDecimal salary);
}