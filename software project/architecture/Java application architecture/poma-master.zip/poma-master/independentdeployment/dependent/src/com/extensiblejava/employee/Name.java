package com.extensiblejava.employee;

public class Name {

}