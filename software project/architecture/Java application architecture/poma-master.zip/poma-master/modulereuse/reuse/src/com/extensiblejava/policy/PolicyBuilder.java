package com.extensiblejava.policy;

public interface PolicyBuilder {
	public Policy build();
}