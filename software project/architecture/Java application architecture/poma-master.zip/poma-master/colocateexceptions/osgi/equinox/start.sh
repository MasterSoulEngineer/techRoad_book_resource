
java -jar org.eclipse.osgi_3.6.0.v20100517.jar -console