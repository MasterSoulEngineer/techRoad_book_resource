package com.extensiblejava.hello.service;

public interface HelloService {

	public String sayHello();

	public String sayGoodbye();
}
