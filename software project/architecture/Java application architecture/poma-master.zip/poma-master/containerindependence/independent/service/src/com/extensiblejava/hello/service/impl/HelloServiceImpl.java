package com.extensiblejava.hello.service.impl;

import java.util.Properties;
import com.extensiblejava.hello.service.HelloService;

public class HelloServiceImpl implements HelloService {

	public String sayHello() {
		return "Hello OSGi Spring World!! ";
	}

	public String sayGoodbye() {
		return "Goodbye OSGi Spring World!!";
	}
}