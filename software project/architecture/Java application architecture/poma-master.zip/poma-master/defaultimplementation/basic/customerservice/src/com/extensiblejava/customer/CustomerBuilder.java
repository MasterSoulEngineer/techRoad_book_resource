package com.extensiblejava.customer;

public interface CustomerBuilder {
	public Customer build();
}