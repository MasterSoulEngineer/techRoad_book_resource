package com.extensiblejava.order;

public interface OrderBuilder {
	public Order[] build();
}