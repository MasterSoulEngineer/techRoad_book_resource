package com.extensiblejava.customer;

public interface CustomerManager {

	public Customer getCustomer();
}