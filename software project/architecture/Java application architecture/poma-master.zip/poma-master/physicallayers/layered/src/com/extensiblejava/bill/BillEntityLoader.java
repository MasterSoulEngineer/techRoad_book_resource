package com.extensiblejava.bill;

public interface BillEntityLoader {
	public Bill loadBill();
}