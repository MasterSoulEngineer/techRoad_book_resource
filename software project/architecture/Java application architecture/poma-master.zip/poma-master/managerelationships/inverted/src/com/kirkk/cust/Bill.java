package com.kirkk.cust;

import java.math.BigDecimal;

public interface Bill {
	public BigDecimal getChargeAmount();
	public BigDecimal pay();

}