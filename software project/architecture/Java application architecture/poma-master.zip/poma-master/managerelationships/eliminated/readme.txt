Remove the cyclic dependency by moving DiscountCalculator and show test passing. Then add the CycleTest to test 
for cyclic dependencies with a more meaningful output.