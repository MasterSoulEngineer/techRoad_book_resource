package com.kirkk.base;

import java.math.BigDecimal;

public interface DiscountCalculator {
	public BigDecimal getDiscountAmount();
}