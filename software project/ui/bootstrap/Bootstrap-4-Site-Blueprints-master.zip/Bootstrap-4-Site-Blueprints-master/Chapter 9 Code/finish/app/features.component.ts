import { Component } from '@angular/core';

@Component({
  selector: 'features',
  template: '<h3>Features</h3>'
})
export class FeaturesComponent { }
