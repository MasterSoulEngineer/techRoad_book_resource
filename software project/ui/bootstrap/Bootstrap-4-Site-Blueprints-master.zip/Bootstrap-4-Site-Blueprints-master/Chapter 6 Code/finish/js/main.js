$('.carousel').carousel({
  interval: 2000
});
