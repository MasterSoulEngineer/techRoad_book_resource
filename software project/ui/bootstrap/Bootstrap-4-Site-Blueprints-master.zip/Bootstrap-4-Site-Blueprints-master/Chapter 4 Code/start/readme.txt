=== JBST 4 ===
Contributors: bassjobsen
Donate link: https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=SNYGRL7YNVYQW
Tags: one-column,two-columns,right-sidebar,responsive-layout,custom-background,custom-colors,custom-header,custom-menu
Requires at least: 4.1-alpha
Tested up to: 4.4.1
Stable tag: 4.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

JBST4 is a blank WordPress theme built with Bootstrap 4.

== Description ==
JBST4 is a blank WordPress theme built with Bootstrap 4. It includes all of the power of Bootstrap 4 into your Wordpress theme. It includes template for a masony grid layout and an off-canvas menu.

== Assets ==
 
 * Bootstrap 4, http://getbooststrap.com/, MIT
 * Tether, http://github.hubspot.com/tether/, MIT

