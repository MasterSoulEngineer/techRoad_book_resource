<div class="container bg-primary-color">
  <nav class="navbar navbar-dark" role="navigation">
  <div class="navbar-toggleable-sm collapse" id="CollapsingNavbar">
    <?php jbst4_top_nav(); ?>
  </div>
  </nav>
</div>
