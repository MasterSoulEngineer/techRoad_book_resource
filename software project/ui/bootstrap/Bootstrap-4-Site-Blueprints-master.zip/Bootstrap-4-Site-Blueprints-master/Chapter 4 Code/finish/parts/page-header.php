<header class="container bg-primary-color-dark">
  <div class="row"> 
      <div class="col-xs-12 bg-primary-color-dark">
         <button class="navbar-toggler hidden-md-up pull-xs-right" type="button" data-toggle="collapse" data-target="#CollapsingNavbar">
           &#9776;
         </button>    
         <h1 class="display-3"><?php bloginfo('name'); ?></h1>
      </div>  
  </div> 
</header>
